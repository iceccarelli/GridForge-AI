# IMAGE PLACEMENT MAP — Time to Power pack v1

Do not integrate until the repository owner asks.

Legend:

- **Required** — the photograph carries part of the commercial story
- **Optional** — improves comprehension if it stays subordinate
- **NO IMAGE** — a photo would weaken the product

Desktop / mobile behaviour is a contract for whoever later wires `next/image`.

---

## `/`  Homepage

| Section | Image | Position | Desktop | Mobile | Why it exists | Required? |
| --- | --- | --- | --- | --- | --- | --- |
| Hero | ttp-01 | Large panoramic background or right-side visual | Type in left negative space; `TimeToPower` remains the data visual; do not stack a second giant photo on the component | Full-width crop under the headline, then the TimeToPower component | Existing campus + electrical connection is the company | Required |
| Problem | ttp-03 | Wide split beside “existing infrastructure is where the decision happens” | 50/50 text + image | Image under the paragraph | Retrofit is the wedge | Required |
| Market statistics | — | — | — | — | Numbers must stay DOM | **NO IMAGE** |
| Live market data | — | — | `LiveConsole` / `LiveScenario` | Same | Live data is the product | **NO IMAGE** |
| How it works | ttp-11 | Small editorial beside workflow copy | ~320–420 px wide, not a banner | Full width, modest height | Inspection is how evidence is gathered | Optional |
| Time-to-Power comparator | — | — | Component only | Component only | Visualization is the product | **NO IMAGE** |
| AI load simulator | — | — | Component only | Component only | Simulator is the product | **NO IMAGE** |
| Qualifier teaser | ttp-04 | Beside the qualifier, never behind it | Image right / form left | Form first, image second | Electrical plant is what the seven numbers are about | Required |
| Services | crops only | Tiny card crops from ttp-04/05, ttp-03/08, ttp-13, ttp-15 | One consistent crop language | Same | Coherence; no 5-photo carnival | Optional |
| Hall Watch card | — | — | Live UI language | Live UI language | Watch is a live model | **NO IMAGE** |
| Headroom Ladder | ttp-06 | Small supporting still only | Ladder SVG primary; photo thumbnail | Ladder only is acceptable | Plant is context, ladder is the product | Optional |
| Technology | ttp-02 | Section visual | 16:9 under or beside copy | 16:9 | Density + liquid cooling | Required |
| Evidence / calibration | ttp-14 | Section visual | Modest 3:2 | Full width modest | Future moat: model vs field | Required |
| Final CTA | ttp-17 | CTA visual | 16:9 under or beside the ask | Full width after copy | The buyer is allocating capital | Required |

Do not put photography in FAQ, founder/about, or market-stat rows.

---

## `/qualify`

Feel: engineering screening instrument, not a marketing page.

| Section | Image | Position | Desktop | Mobile | Why it exists | Required? |
| --- | --- | --- | --- | --- | --- | --- |
| Form | — | Form is first | Form left | Form first | Conversion | **NO IMAGE above the form** |
| Support | ttp-04 | Side panel | Right column | Below the form | Electrical plant being screened | Required |
| Secondary | ttp-05 | Under ttp-04 or after first result | Optional 3:2 | Optional | Tap-off is the named failure mode | Optional |

---

## `/q/[token]`

| Section | Image | Position | Desktop | Mobile | Why it exists | Required? |
| --- | --- | --- | --- | --- | --- | --- |
| Result | — | Binding constraint, racks, date-setting item, evidence | HTML dominant | HTML dominant | The result is the product | **NO IMAGE** |

---

## `/constraints`

Authority page. Not a gallery.

| Section | Image | Position | Desktop | Mobile | Why it exists | Required? |
| --- | --- | --- | --- | --- | --- | --- |
| Electrical group | ttp-04 | Above or beside the electrical cards | 3:2, constrained width | Full width modest | Domain identity | Required |
| Thermal group | ttp-08 | Above or beside the thermal cards | 16:9 modest | Full width modest | Domain identity | Required |
| Physical group | ttp-10 | Above or beside the physical cards | 4:3 modest | Full width modest | Domain identity | Required |
| The 13 cards | — | Text only | DOM | DOM | Machine-readable names, relations, relief, lead time, source | **NO IMAGE** |

---

## `/constraints/[slug]`

| Section | Image | Position | Desktop | Mobile | Why it exists | Required? |
| --- | --- | --- | --- | --- | --- | --- |
| Header support | mapped master (see IMAGE_MANIFEST.md) | Beside title / above body | Modest | Modest | Physical referent | Optional |
| Governing relation | — | — | Math/text/SVG | Same | Do not bake equations into photos | **NO IMAGE** |
| Worked example | — | — | Text | Text | Numbers are application output | **NO IMAGE** |

Mapping reminder:

- tap-off / busway → ttp-05  
- transformer / switchgear / UPS → ttp-04 or ttp-06  
- grid / firm supply → ttp-09  
- chiller / CW temperature → ttp-08  
- CDU / flow → ttp-07  
- residual air / per-rack cooling → ttp-02  
- floor loading → ttp-10  
- rack positions / clearance → ttp-03  

---

## `/platforms`

| Section | Image | Position | Desktop | Mobile | Why it exists | Required? |
| --- | --- | --- | --- | --- | --- | --- |
| Intro | ttp-02 | Visual anchor | 16:9 modest | Full width modest | What the hall has to carry | Optional |
| Physical note | ttp-10 | Second anchor near floor-loading copy | 4:3 modest | After copy | Floor loading is a first-class platform field | Optional |
| Platform table | — | — | Real DOM table | Real DOM table | Reference surface | **NO IMAGE of the table** |

---

## `/reference`

| Section | Image | Position | Desktop | Mobile | Why it exists | Required? |
| --- | --- | --- | --- | --- | --- | --- |
| Document/model pack explanation | ttp-12 | Beside that paragraph | Modest 16:9 | After paragraph | Data-room discipline | Optional |
| Live report / deck / model-pack links | — | Live HTML links | Links | Links | Authority surface | **NO IMAGE gallery** |

---

## `/developers`

| Section | Image | Position | Desktop | Mobile | Why it exists | Required? |
| --- | --- | --- | --- | --- | --- | --- |
| Machine interface intro | ttp-16 | Beside explanation | Modest 16:9 | After intro | Engineer + plant + interface | Optional |
| `/v1/tools`, MCP, JSON, units, evidence classes, calibration, pricing | — | Actual HTML/code | Code | Code | Crawlers and agents must read schemas | **NO IMAGE** |

---

## `/pricing`

| Section | Image | Position | Desktop | Mobile | Why it exists | Required? |
| --- | --- | --- | --- | --- | --- | --- |
| Above the price table | — | — | — | — | Buying page | **NO IMAGE** |
| Between intro copy and product ladder | ttp-11 | Narrow editorial strip | max ~280 px tall | Optional omit | Inspection seriousness | Optional |
| Inside every pricing card | — | — | — | — | Cards must stay what / price / turnaround / deliverable | **NO IMAGE** unless a tiny crop of ttp-04/05, ttp-03/08, ttp-13, ttp-15 is used consistently |

---

## `/intake/[token]`

| Section | Image | Position | Desktop | Mobile | Why it exists | Required? |
| --- | --- | --- | --- | --- | --- | --- |
| Form | — | Dominates | Form | Form | Completion | **NO competing banner** |
| Sidebar | ttp-12 | Top-right or side | Narrow | Omit on small screens | Data-room expectation | Optional |

---

## `/deliverable/[token]`

| Section | Image | Position | Desktop | Mobile | Why it exists | Required? |
| --- | --- | --- | --- | --- | --- | --- |
| Report / evidence / model pack / constraints | — | Real generated UI | UI | UI | The deliverable is the product | **NO stock photography** |
| Subordinate support | ttp-11 | Small, if needed | Thumbnail | Omit | Human inspection, not decoration | Optional |

---

## `/watch/[token]`

| Section | Image | Position | Desktop | Mobile | Why it exists | Required? |
| --- | --- | --- | --- | --- | --- | --- |
| Status / change history | — | INPUT CHANGED → CONSTRAINT MOVED → CAPACITY MOVED → DATE MOVED as UI | UI | UI | Watch is a live model | **NO IMAGE-first page** |
| Optional context | ttp-14 | Small | Thumbnail | Omit | Field measurement as the reason watch exists | Optional |

---

## `/api-access/[token]`

| Section | Image | Position | Desktop | Mobile | Why it exists | Required? |
| --- | --- | --- | --- | --- | --- | --- |
| Key / quota / expiry / instructions | — | Operational panels | Panels | Panels | Operator page | **NO IMAGE** |

---

## `/dashboard`  `/account`

| Section | Image | Position | Desktop | Mobile | Why it exists | Required? |
| --- | --- | --- | --- | --- | --- | --- |
| Customer data / deliverables | — | Real objects | — | — | Real work > decoration | **NO GENERATED IMAGE** |

---

## `/intelligence`

Audit result: the live route still reads as a **building-toward** siting/intelligence surface, not a finished verified-site product.

| Section | Image | Position | Desktop | Mobile | Why it exists | Required? |
| --- | --- | --- | --- | --- | --- | --- |
| If the route stays public | ttp-15 | One metaphor only | Modest 16:9 | Modest | Portfolio comparison as a future layer | Optional, and only with “building toward / intelligence layer” copy |
| Alternative | — | Demote the route in nav | — | — | Do not use photography to fake product maturity | Prefer demotion over a hero |

Never use ttp-15 here as “our live portfolio of powered sites.”

---

## Other public routes observed in the current site

These exist on the live nav or app tree and were audited for this pack.

| Route | Image rule |
| --- | --- |
| `/architectures` | **NO new master.** If a visual is needed later, crop ttp-02 / ttp-08. Architecture comparison must stay application output. |
| `/technology` | Crop ttp-02. Do not illustrate “AI brains” or EMS holograms. |
| `/about` | **NO generated founder likeness.** Do not invent a portrait. |
| `/legal/*` | **NO IMAGE** |
| `/admin/*` | **NO IMAGE** |
| `/commissioned/*` | Real commission UI; **NO decorative photo** |

---

## Social / OG

`public/og.png` already exists in the repo.

Candidate replacement later (not in this integration): a 1200×630 crop of **ttp-01** with HTML type overlaid by the app, never baked into the photograph.

---

## Navbar / Footer

**NO IMAGE.** Wordmark and text links only.

---

## Components that must never become rasters

`TimeToPower`  
`TimeToPowerComparator`  
`LoadSimulator`  
`LiveConsole`  
`LiveScenario`  
`BindingConstraintInsights`  
`SystemFlow`  
`HeroReel` (unless the owner later chooses to feed it these stills as frames — not requested)  
`CommissionScreen`  
`McpInstall`  
`ApiPlans`  
Headroom Ladder / EngagementLadder visualizations  

---

## Visual story check

A visitor who only glances at the photographs should still read:

1. This is an existing data center.  
2. The question is how much AI compute it can actually support.  
3. The limit can be electrical.  
4. The limit can be thermal.  
5. The limit can be physical.  
6. Time to Power calculates the envelope.  
7. The headroom ladder (UI, not photo) shows how to move the limit.  
8. Procurement turns relief into a specification.  
9. Field data eventually tells us whether the model was right.  

If a future crop or placement tells a different company story (we sell batteries, we build halls, we have a live verified portfolio), reject the crop.
