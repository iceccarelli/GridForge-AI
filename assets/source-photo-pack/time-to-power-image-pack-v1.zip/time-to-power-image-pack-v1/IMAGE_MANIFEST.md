# IMAGE MANIFEST — Time to Power pack v1

All 17 masters. Reuse by crop. Do not generate one image per card.

| Asset | Filename | Routes | Placement | Purpose | Aspect | Alt Text |
| ----- | -------- | ------ | --------- | ------- | ------ | -------- |
| ttp-01 | ttp-01-existing-data-center-campus-hero.webp | `/` | Homepage hero background / side visual; OG/social candidate | Existing campus + electrical connection + data hall in one frame. Left negative space for type. | 21:9 (3840×1646) | Elevated view of an existing European data-center campus with on-site electrical substation, transformers and service roads. |
| ttp-02 | ttp-02-high-density-ai-rack-liquid-cooling.webp | `/`, `/platforms`, `/constraints/[slug]` (thermal) | Technology section; platform library anchor | High-density liquid-cooled AI hall | 16:9 (3200×1800) | Data-center hall with rows of high-density compute racks and overhead liquid-cooling pipework. |
| ttp-03 | ttp-03-existing-hall-retrofit.webp | `/`, `/platforms`, `/constraints/[slug]` (physical) | Problem / envelope-study support | What an existing hall can actually take | 16:9 (3200×1800) | Existing data-center hall with legacy lower-density racks and a denser liquid-cooled AI rack zone being retrofitted. |
| ttp-04 | ttp-04-electrical-room-switchgear-transformer.webp | `/`, `/qualify`, `/constraints`, `/constraints/[slug]` (electrical) | Qualifier side panel; electrical domain | Binding electrical plant | 3:2 (2400×1600) | Data-center electrical room with distribution switchgear, a transformer section, copper bus and cable trays. |
| ttp-05 | ttp-05-busway-tapoff-detail.webp | `/qualify`, `/constraints/[slug]` (busway / tap-off) | Qualifier secondary; density-screen crop | 63 A tap-off / busway constraint | 3:2 (2400×1600) | Overhead data-center busway and rack tap-off enclosure feeding a high-density rack. |
| ttp-06 | ttp-06-transformer-switchgear-corridor.webp | `/`, `/constraints`, envelope study | Small support next to Headroom Ladder UI | Electrical capacity / relief | 16:9 (3200×1800) | Service corridor of a data-center electrical plant with transformers and MV/LV switchgear. |
| ttp-07 | ttp-07-liquid-cooling-cdu.webp | `/constraints`, `/platforms`, `/constraints/[slug]` (CDU / flow) | Thermal constraint / procurement thermal | Facility CDU | 3:2 (2400×1600) | Facility coolant distribution unit with pumps, heat-exchange pipework and connections toward liquid-cooled racks. |
| ttp-08 | ttp-08-data-center-mechanical-cooling-plant.webp | `/`, `/constraints`, envelope study | Thermal domain group | Chilled-water plant | 16:9 (3200×1800) | Data-center mechanical plant with insulated chilled-water pipework, pumps and heat-exchange equipment. |
| ttp-09 | ttp-09-data-center-substation.webp | `/`, `/constraints/[slug]` (grid / firm supply) | Grid-to-site explanation | Utility connection | 16:9 (3200×1800) | Utility substation with transformers and buswork adjacent to data-center buildings. |
| ttp-10 | ttp-10-heavy-ai-rack-raised-floor.webp | `/platforms`, `/constraints`, `/constraints/[slug]` (floor loading) | Physical domain | Floor loading | 4:3 (2400×1800) | High-density AI rack base standing on a raised-floor tile system with liquid-cooling connections at the cabinet. |
| ttp-11 | ttp-11-engineer-site-inspection.webp | `/`, `/pricing`, `/deliverable/[token]`, `/intake` | How-it-works / trust / narrow pricing strip | Inspection workflow | 3:2 (2400×1600) | Facilities engineer inspecting data-center rack infrastructure while holding a tablet. |
| ttp-12 | ttp-12-engineering-data-room-review.webp | `/reference`, `/intake/[token]` | Data-room / intake sidebar | Study and document review | 16:9 (3200×1800) | Engineers reviewing data-center drawings and single-line documents in a technical meeting room. |
| ttp-13 | ttp-13-procurement-bid-review.webp | `/`, procurement product, `/pricing` (tiny crop only) | Procurement specification | Bid comparison environment | 16:9 (3200×1800) | Engineers and procurement professionals reviewing supplier submissions for data-center infrastructure. |
| ttp-14 | ttp-14-field-calibration-instrumentation.webp | `/`, `/watch/[token]` (optional) | Evidence / calibration | Model versus field | 3:2 (2400×1600) | Clamp-on electrical measurement and pipe-mounted thermal sensors installed in an operational data-center hall. |
| ttp-15 | ttp-15-multi-site-data-center-portfolio.webp | `/`, `/intelligence` (with “building toward” copy only) | Portfolio screen metaphor | Multi-site comparison, not customer sites | 16:9 (3200×1800) | Aerial view of several data-center campuses and substations in a European industrial landscape. |
| ttp-16 | ttp-16-engineer-machine-interface.webp | `/developers` | Beside machine-interface copy | API / MCP context | 16:9 (3200×1800) | Infrastructure engineer working at a workstation beside live server racks, screens unreadable. |
| ttp-17 | ttp-17-infrastructure-decision-room.webp | `/` final CTA | Capital-decision close | High-value buyer | 16:9 (3200×1800) | Infrastructure investment meeting in a boardroom overlooking a data-center campus. |

---

## Constraint slug → master mapping

Do not generate 13 photos. Map slugs to these files.

### Electrical → ttp-04 / ttp-05 / ttp-06 / ttp-09

| Typical slug theme | Master |
| --- | --- |
| Rack feed / tap-off rating | ttp-05 |
| Busway ampacity | ttp-05 |
| Transformer capacity | ttp-04 or ttp-06 |
| Switchgear capacity | ttp-04 or ttp-06 |
| UPS capacity | ttp-04 |
| Firm supply / grid connection | ttp-09 |

### Thermal → ttp-07 / ttp-08 / ttp-02

| Typical slug theme | Master |
| --- | --- |
| Chiller / chilled-water plant | ttp-08 |
| Cooling-water temperature | ttp-08 |
| Liquid-cooling flow | ttp-07 |
| CDU capacity | ttp-07 |
| Residual air removal | ttp-02 |
| Cooling architecture per rack | ttp-02 |

### Physical → ttp-10 / ttp-03

| Typical slug theme | Master |
| --- | --- |
| Floor loading | ttp-10 |
| Rack positions / space / clearance | ttp-03 |

---

## Service card crops (homepage / pricing)

Do **not** give every card a unique generated image.

| Product | Crop from |
| --- | --- |
| Density Screen | ttp-04 or ttp-05 |
| Envelope Study | ttp-03 or ttp-08 |
| Procurement Specification | ttp-13 |
| Portfolio Screen | ttp-15 |
| Hall Watch | **no photo** — live UI |
| API / MCP | ttp-16 only on `/developers` |

---

## DO NOT USE IMAGE — USE ACTUAL UI / SVG

These surfaces must remain machine-readable DOM, SVG, or JSON. A photograph is inferior and commercially dishonest if it replaces them.

- Market statistics (`MARKET_STATS`)
- Time-to-Power comparator (`TimeToPower`, `TimeToPowerComparator`)
- Load simulator (`LoadSimulator`)
- Live market console (`LiveConsole`, `LiveScenario`)
- Headroom Ladder
- Constraint equations and worked examples
- Binding-constraint qualifier form and results
- Platform capability table
- API schemas, `/v1/tools`, MCP tool catalogue
- Pricing tables (what / price / turnaround / deliverable)
- Bid-comparison ranking (racks and weeks)
- Calibration statistics and evidence class
- Qualification result pages (`/q/[token]`)
- Deliverable contents (`/deliverable/[token]`)
- Watch input-change history (`/watch/[token]`)
- API access quota / key panel (`/api-access/[token]`)
- Private dashboard customer data
- JSON-LD and `llms.txt`

---

## Crop cheat-sheet

```
ttp-01  object-position: 72% 48%;  hero left third is road/pad negative space
ttp-02  object-position: 50% 40%;  keep aisle vanishing point
ttp-03  object-position: 60% 50%;  keep retrofit cluster on the right
ttp-04  object-position: 35% 50%;  transformer + copper bus
ttp-05  object-position: 55% 40%;  tap-off box
ttp-06  object-position: 50% 55%;  yellow floor markings + transformers
ttp-07  object-position: 30% 55%;  CDU enclosure
ttp-08  object-position: 40% 50%;  insulated mains
ttp-09  object-position: 50% 45%;  transformers, buildings behind
ttp-10  object-position: 45% 70%;  floor tiles + rack feet
ttp-11  object-position: 40% 40%;  engineer + open rack
ttp-12  object-position: 50% 70%;  drawings on table
ttp-13  object-position: 50% 55%;  table documents, not the window
ttp-14  object-position: 20% 50%;  clamp meter
ttp-15  object-position: 50% 45%;  campuses + substation
ttp-16  object-position: 70% 45%;  racks behind the operator
ttp-17  object-position: 50% 40%;  people + campus through glass
```
