# Time to Power — Master Realistic Image Pack v1

Synthetic documentary photography for [timetopower.ai](https://timetopower.ai) / GridForge Engine.

**Status:** image pack only. Not integrated into production.

These assets are **generated reference photographs**. They are not customer sites, not licensed stock of named facilities, and not evidence of measured performance.

---

## Philosophy

Time to Power sells an infrastructure **decision**, not hardware.

The visual story is:

> SITE → CAPACITY → CONSTRAINT → HEADROOM → COST → TIME → PROCUREMENT → VALIDATION

Every photograph is the physical environment only.  
Every number, label, equation, API schema, price, and constraint name lives in HTML / SVG / JSON.

The intended look is:

**Bloomberg Terminal × high-end engineering consultancy × data-center operator × infrastructure diligence**

Not crypto, not neon “AI”, not vendor product shots, not handshake stock.

---

## Website audit (before generation)

Inspected live site `https://timetopower.ai` and public repo `https://github.com/iceccarelli/GridForge-AI`.

Findings that governed this pack:

| Surface | What exists today | Implication for photography |
| --- | --- | --- |
| Homepage | DOM/SVG product visuals: `HeroReel`, `TimeToPower`, `LiveConsole`, `LiveScenario`, `TimeToPowerComparator`, `LoadSimulator`, `BindingConstraintInsights`, `SystemFlow`, `CommissionScreen` | Do **not** replace any of these with rasters |
| `/qualify` | Engineering screening form; no photos | Photo may sit beside the form, never above it |
| `/constraints` | Authority text for 13 constraints; no gallery | Three domain photos only |
| `/constraints/[slug]` | Worked examples in text/math | Reuse masters; do not mint 13 photos |
| `/platforms` | Platform table is the product | Two anchors only |
| `/reference` | Live links to generated reports/decks | One data-room photo |
| `/developers` | Live `/v1/tools`, MCP, schemas | One machine-interface photo; schemas stay HTML |
| `/pricing` | Price / turnaround / deliverable table | Narrow editorial strip at most |
| Token routes | Qual result, intake, deliverable, watch, API access | Form/result UI dominates; photo optional or none |
| `/intelligence` | Building-toward language, not a mature verified-site product | Use portfolio metaphor only with “building toward” copy — do not fake maturity |
| `public/` | `icon.svg`, `og.png`, `reference/` | No existing photographic system |
| Visual language | Restrained technical UI, Lucide icons, live data figures | Photography must stay industrial and documentary |

**Copy tension (recorded, not papered over):**  
The live homepage still carries older “behind-the-meter generation / EMS / BESS” language in places. This pack follows the current commercial promise in the brief:

> Give Time to Power the technical information for an existing or proposed AI site, and it tells you how much useful AI compute the site can actually support, what blocks it, what fixes it, what the fix costs, and when the compute can go live.

Photography therefore shows **existing halls, electrical plant, thermal plant, constraints, engineering workflow, procurement, calibration, and capital decision**. It does **not** show generators, BESS products, microgrids, GPUs for sale, or EPC construction as the product.

---

## Pack contents

```
time-to-power-image-pack-v1/
  images/          17 master WebP files for the site
  sources/         original generated JPEGs (pre-crop, native model resolution)
  manifest/        machine-readable extras
  README.md
  IMAGE_MANIFEST.md
  IMAGE_METADATA.json
  IMAGE_PLACEMENT_MAP.md
```

| File | Purpose |
| --- | --- |
| `images/*.webp` | Production-candidate masters |
| `sources/ttp-NN-source.jpg` | Uncropped generation source |
| `IMAGE_MANIFEST.md` | Human table + “do not replace UI” list |
| `IMAGE_METADATA.json` | Per-asset metadata for engineering |
| `IMAGE_PLACEMENT_MAP.md` | Route × section × behaviour |

---

## The 17 masters

1. `ttp-01-existing-data-center-campus-hero.webp` — existing campus + electrical connection  
2. `ttp-02-high-density-ai-rack-liquid-cooling.webp` — AI rack density / liquid cooling  
3. `ttp-03-existing-hall-retrofit.webp` — legacy hall vs dense retrofit zone  
4. `ttp-04-electrical-room-switchgear-transformer.webp` — binding electrical constraint  
5. `ttp-05-busway-tapoff-detail.webp` — 63 A tap-off / busway  
6. `ttp-06-transformer-switchgear-corridor.webp` — electrical headroom ladder  
7. `ttp-07-liquid-cooling-cdu.webp` — CDU / liquid-cooling plant  
8. `ttp-08-data-center-mechanical-cooling-plant.webp` — chilled-water mechanical plant  
9. `ttp-09-data-center-substation.webp` — grid → site connection  
10. `ttp-10-heavy-ai-rack-raised-floor.webp` — floor loading / physical constraint  
11. `ttp-11-engineer-site-inspection.webp` — inspection / evidence workflow  
12. `ttp-12-engineering-data-room-review.webp` — intake / data-room review  
13. `ttp-13-procurement-bid-review.webp` — procurement specification  
14. `ttp-14-field-calibration-instrumentation.webp` — model vs field  
15. `ttp-15-multi-site-data-center-portfolio.webp` — portfolio metaphor (not customer sites)  
16. `ttp-16-engineer-machine-interface.webp` — API / MCP / developers  
17. `ttp-17-infrastructure-decision-room.webp` — capital decision CTA  

---

## Cropping guidance

Do not mint a new file per card. Use `next/image` + `object-fit` + `object-position`.

| Use | Ratio | object-position hint |
| --- | --- | --- |
| Homepage hero | 21:9 | `object-position: 70% 50%` (campus + yard on the right; type on the left) |
| Desktop section | 16:9 | center |
| Editorial / qualify side | 3:2 | center or slightly left for equipment |
| Physical / electrical cards | 4:3 | lower-third for floor-loading crop of ttp-10 |
| Tiny card | 1:1 | tight center crop of the relevant object |

Avoid 9:16 unless a genuine mobile-only feature needs it.

---

## Performance

Masters are WebP, typically 140–390 KB.

Recommended Next.js usage:

- Hero (`ttp-01`): `priority`, not lazy-loaded  
- Below-the-fold: lazy  
- `sizes` matching actual layout, not the 3840px master  
- Do not ship the `sources/` JPEGs to the browser  

Native model output is ~1176×784. Display masters are Lanczos-upscaled to the brief dimensions. If a licensed photograph later replaces a master, keep the **filename** so crops and maps stay stable.

---

## Accessibility

- Meaningful engineering photos: descriptive `alt` from `IMAGE_METADATA.json`  
- Decorative crops / backgrounds behind existing UI: `alt=""`  
- No critical constraint, price, date, or capacity value lives only in a photo  

---

## Prohibited uses

Do not use these images to imply Time to Power sells:

- generators, BESS, microgrids, cooling equipment, GPUs, data halls, or EPC services  
- named customer sites  
- measured site performance  
- vendor products (NVIDIA, Schneider, Eaton, Vertiv, etc.)  

Do not:

- bake equations, API JSON, or dashboards into the photographs  
- replace `TimeToPower`, `LoadSimulator`, Headroom Ladder, pricing tables, or `/v1` schemas with rasters  
- present `ttp-15` as actual Time to Power customer campuses  
- use imagery on `/intelligence` to make the verified-site layer look finished  

---

## Legal / honesty

- `synthetic: true` on every asset  
- `customerAsset: false` on every asset  
- `vendorBranded: false` on every asset  
- People are anonymized generated figures, not real identifiable customers  
- Documents and screens in the frames are intentionally unreadable  

Replace with licensed photography of real (permitted) facilities when that photography exists.

---

## Integration

Do **not** integrate this pack into the Next.js app unless the repository owner explicitly asks.

When integration is requested:

1. Place files under something like `public/images/ttp/`  
2. Keep filenames stable  
3. Apply `IMAGE_PLACEMENT_MAP.md` only  
4. Leave every engineering visualization as DOM/SVG  

---

## QA notes (v1)

Accepted as coherent documentary set.

Known limits (do not hide):

- Generated, not photographed; some micro-texture on paper documents may resemble text at 100% zoom. Treat as texture, never as data.  
- `ttp-08` is an indoor chilled-water / mechanical plant, not a rooftop air-cooled chiller yard. That is the correct thermal-domain image for “plant capacity”.  
- `ttp-15` is a composed multi-campus metaphor in a European landscape, not a geolocated portfolio.  
- Warning-triangle **shapes** appear on switchgear. No usable words.  
- People in 11–13, 16–17 are generated professionals. Do not caption them as staff or clients.  

Rejected and replaced during generation:

- First `ttp-10` candidate (oversized multi-chassis cube) was discarded in favour of a standard rack base on raised floor.  
